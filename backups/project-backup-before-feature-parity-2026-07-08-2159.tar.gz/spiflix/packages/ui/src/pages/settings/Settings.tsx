import { useState } from 'react'
import { useTheme } from '@/app/providers/theme-provider'
import { usePersistentState } from '@/hooks/useLocalStorage'
import {
  Monitor, Moon, Sun, Palette, Play, Trash2, ExternalLink,
  History, Globe, ChevronLeft,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useNavigate } from 'react-router-dom'

const themes = [
  { id: 'dark' as const, label: 'Dark', icon: Moon },
  { id: 'light' as const, label: 'Light', icon: Sun },
  { id: 'system' as const, label: 'System', icon: Monitor },
]

const colorThemes = [
  { id: 'default' as const, label: 'Red', color: 'bg-red-500' },
  { id: 'blue' as const, label: 'Blue', color: 'bg-blue-500' },
  { id: 'green' as const, label: 'Green', color: 'bg-green-500' },
  { id: 'purple' as const, label: 'Purple', color: 'bg-purple-500' },
  { id: 'amber' as const, label: 'Amber', color: 'bg-amber-500' },
  { id: 'sky' as const, label: 'Sky', color: 'bg-sky-500' },
  { id: 'rose' as const, label: 'Rose', color: 'bg-rose-500' },
]

type Tab = 'appearance' | 'playback' | 'history' | 'backend'

export default function Settings() {
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState<Tab>('appearance')
  const { theme, colorTheme, setTheme, setColorTheme } = useTheme()
  const [autoplayNext, setAutoplayNext] = usePersistentState('spiflix-autoplay-next', true)
  const [omssUrl, setOmssUrl] = usePersistentState('spiflix-omss-url', '')

  const watchHistory = typeof window !== 'undefined'
    ? Object.keys(localStorage)
        .filter(k => k.startsWith('playback_'))
        .map(k => {
          try {
            const data = JSON.parse(localStorage.getItem(k) || '{}')
            const [, type, id] = k.split('_')
            return { key: k, type, id, title: data.title || id, progress: data.currentTime || 0, duration: data.duration || 0, updated: data.updated || 0 }
          } catch { return null }
        })
        .filter(Boolean)
        .sort((a: any, b: any) => (b.updated || 0) - (a.updated || 0))
        .slice(0, 50)
    : []

  const clearWatchHistory = () => {
    const keys = Object.keys(localStorage).filter(k => k.startsWith('playback_'))
    keys.forEach(k => localStorage.removeItem(k))
  }

  const tabs: { id: Tab; label: string; icon: any }[] = [
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'playback', label: 'Playback', icon: Play },
    { id: 'history', label: 'History', icon: History },
    { id: 'backend', label: 'Backend', icon: ExternalLink },
  ]

  return (
    <div className="mx-auto max-w-4xl py-8 px-4 sm:px-6">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="rounded-lg p-2 text-muted-foreground hover:bg-muted">
          <ChevronLeft className="h-5 w-5" />
        </button>
        <h1 className="text-2xl font-bold">Settings</h1>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border mb-6 overflow-x-auto">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            className={cn(
              'flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap',
              activeTab === id
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground',
            )}
          >
            <Icon className="h-4 w-4" />
            {label}
          </button>
        ))}
      </div>

      {/* Appearance */}
      {activeTab === 'appearance' && (
        <div className="space-y-8">
          <section>
            <p className="text-sm text-muted-foreground mb-3">Theme</p>
            <div className="flex gap-2">
              {themes.map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setTheme(id)}
                  className={cn(
                    'flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors',
                    theme === id ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:bg-muted/80',
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {label}
                </button>
              ))}
            </div>
          </section>

          <section>
            <p className="text-sm text-muted-foreground mb-3">Accent Color</p>
            <div className="flex gap-2 flex-wrap">
              {colorThemes.map(({ id, label, color }) => (
                <button
                  key={id}
                  onClick={() => setColorTheme(id)}
                  className={cn(
                    'flex h-9 w-9 items-center justify-center rounded-full transition-all',
                    colorTheme === id && 'ring-2 ring-primary ring-offset-2 ring-offset-background',
                  )}
                  title={label}
                >
                  <div className={cn('h-5 w-5 rounded-full', color)} />
                </button>
              ))}
            </div>
          </section>
        </div>
      )}

      {/* Playback */}
      {activeTab === 'playback' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between py-3 border-b border-border">
            <div>
              <p className="text-sm font-medium">Autoplay Next Episode</p>
              <p className="text-xs text-muted-foreground">Automatically play the next episode after a 5s countdown</p>
            </div>
            <button
              onClick={() => setAutoplayNext(!autoplayNext)}
              className={cn('relative h-6 w-11 rounded-full transition-colors', autoplayNext ? 'bg-primary' : 'bg-muted')}
            >
              <div className={cn('absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform', autoplayNext ? 'translate-x-5' : 'translate-x-0.5')} />
            </button>
          </div>
        </div>
      )}

      {/* History */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">{watchHistory.length} items</p>
            {watchHistory.length > 0 && (
              <button
                onClick={clearWatchHistory}
                className="flex items-center gap-1.5 rounded-lg bg-destructive/10 px-3 py-1.5 text-xs font-medium text-destructive hover:bg-destructive/20"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Clear All
              </button>
            )}
          </div>

          {watchHistory.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No watch history yet</p>
          ) : (
            <div className="space-y-2">
              {watchHistory.map((item: any) => {
                const pct = item.duration > 0 ? Math.round((item.progress / item.duration) * 100) : 0
                return (
                  <div
                    key={item.key}
                    onClick={() => {
                      const path = item.type === 'movie'
                        ? `/watch/movie/${item.id}`
                        : `/watch/tv/${item.id}?s=1&e=1`
                      navigate(path)
                    }}
                    className="flex items-center justify-between rounded-lg border border-border p-3 cursor-pointer hover:bg-muted transition-colors"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate">{item.title}</p>
                      <p className="text-xs text-muted-foreground">{item.type === 'movie' ? 'Movie' : 'TV'}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-16 rounded-full bg-muted overflow-hidden">
                        <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs text-muted-foreground">{pct}%</span>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      )}

      {/* Backend */}
      {activeTab === 'backend' && (
        <div className="space-y-6">
          <div>
            <p className="text-sm font-medium mb-2">Backend URL</p>
            <input
              type="url"
              value={omssUrl}
              onChange={(e) => setOmssUrl(e.target.value)}
              placeholder="Leave empty for default"
              className="w-full rounded-lg border border-border bg-muted px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Custom backend URL. Leave empty to use the default.
            </p>
          </div>

          <div className="rounded-lg border border-border p-3">
            <p className="text-sm font-medium mb-1">Connection Status</p>
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-green-500" />
              <span className="text-xs text-muted-foreground">Connected</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
