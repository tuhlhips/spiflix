import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { ThemeProvider } from './app/providers/theme-provider'
import { DrawerProvider } from './app/providers/drawer-provider'
import { Toaster } from 'sonner'
import App from './app/App'
import './index.css'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <ThemeProvider>
        <DrawerProvider>
          <App />
          <Toaster position="bottom-right" richColors />
        </DrawerProvider>
      </ThemeProvider>
    </BrowserRouter>
  </StrictMode>,
)
