import { useEffect, useRef } from 'react'
import { parseVTT } from '@/lib/subtitles'

interface CustomSubtitlesProps {
  url: string
  videoRef: React.RefObject<HTMLVideoElement | null>
}

export function CustomSubtitles({ url, videoRef }: CustomSubtitlesProps) {
  const trackRef = useRef<TextTrack | null>(null)

  useEffect(() => {
    const video = videoRef.current
    if (!video || !url) return

    let cancelled = false

    async function load() {
      try {
        const res = await fetch(url)
        const text = await res.text()
        if (cancelled) return

        let vttText = text

        // Handle HLS playlist wrapping a VTT segment
        if (text.startsWith('#EXTM3U')) {
          const match = text.match(/^https?:\/\/.+\.vtt[^\s]*/m)
          if (match) {
            try {
              const vttRes = await fetch(match[0])
              vttText = await vttRes.text()
            } catch { return }
          } else { return }
        }

        if (cancelled) return

        const cues = parseVTT(vttText)
        if (cues.length === 0) return

        // Create track and populate cues
        const track = video!.addTextTrack('subtitles', 'English', 'en')
        track.mode = 'showing'
        trackRef.current = track

        for (const cue of cues) {
          try {
            const vttCue = new VTTCue(cue.start, cue.end, cue.text)
            track.addCue(vttCue)
          } catch {}
        }
      } catch {}
    }

    // Clean up previous track before loading new one
    if (trackRef.current) {
      trackRef.current.mode = 'disabled'
      trackRef.current = null
    }

    load()
    return () => {
      cancelled = true
      if (trackRef.current) {
        trackRef.current.mode = 'disabled'
        trackRef.current = null
      }
    }
  }, [url, videoRef])

  return null
}
